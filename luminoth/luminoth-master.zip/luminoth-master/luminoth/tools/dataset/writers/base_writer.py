
class BaseWriter(object):
    """BaseWriter for saving tfrecords.
    """
    def __init__(self):
        super(BaseWriter, self).__init__()
