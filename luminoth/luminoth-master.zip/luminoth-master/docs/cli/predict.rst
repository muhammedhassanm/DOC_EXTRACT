.. _cli/predict:

Predict with a model
====================
