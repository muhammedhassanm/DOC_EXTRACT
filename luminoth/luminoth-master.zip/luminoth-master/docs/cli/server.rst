.. _cli/server:

Web server
==========
