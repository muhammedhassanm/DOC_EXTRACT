.. _cli/eval:

Evaluating a model
==================
