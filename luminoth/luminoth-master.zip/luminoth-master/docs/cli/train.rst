.. _cli/train:

Training a model
================
