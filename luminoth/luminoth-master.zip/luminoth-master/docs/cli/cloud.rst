.. _cli/cloud:

Cloud management
================
