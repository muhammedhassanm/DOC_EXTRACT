.. _cli/checkpoint:

Checkpoint management
=====================
