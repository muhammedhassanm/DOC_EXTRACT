.. _cli/dataset:

Dataset management
==================
