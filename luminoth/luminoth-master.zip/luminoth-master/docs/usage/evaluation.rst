.. _usage/evaluation:

Evaluating a model
==================
